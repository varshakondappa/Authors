import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "@reach/router";
import ProductForm from "../components/ProductForm";
const Products = (props) => {
  const [product, setProduct] = useState([]);
  const deleteProductById = (productId) => {
    axios
      .delete("http://localhost:8000/api/products/" + productId)
      .then((res) => console.log(res.data));
  };
  useEffect(() => {
    axios
      .get("http://localhost:8000/api/products")
      .then((res) => {
        setProduct(res.data);
      })
      .catch((err) => console.log(err));
  });

  return (
    <>
      <ProductForm />
      <hr />
      <h2>All products</h2>
      <div>
        {product.map((item, idx) => {
          return (
            <p key={idx}>
              <Link to={"/products/" + item._id}>{item.title}</Link>
              <br />
              <Link to={"/products/" + item._id + "/edit"}>Edit</Link>
              <button
                onClick={(e) => {
                  deleteProductById(item._id);
                }}
              >
                Delete
              </button>
            </p>
          );
        })}
      </div>
    </>
  );
};

export default Products;
