import React, { useState } from "react";
import axios from "axios";
const ProductForm = (e) => {
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const submitHandler = (e) => {
    e.preventDefault();
    const newProduct = {
      title,
      price,
      description,
    };
    axios
      .post("http://localhost:8000/api/products", newProduct)
      .then((res) => console.log(res.data))
      .catch((err) => console.log(err));
    setTitle("");
    setPrice("");
    setDescription("");
  };
  return (
    <form onSubmit={submitHandler}>
      <h2>Product Form</h2>
      <div className="product">
        <div className="title">
          <label>TITLE </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        <br />
        <div className="price">
          <label>PRICE </label>
          <input
            type="text"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
          />
        </div>
        <br />
        <div className="desc">
          <label>DESCRIPTION </label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
      </div>
      <br />
      <button type="submit">Create</button>
    </form>
  );
};
export default ProductForm;
