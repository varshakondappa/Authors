import React, { useState, useEffect } from "react";
import axios from "axios";
const UpdatedById = (props) => {
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  useEffect(() => {
    axios.get("http://localhost:8000/api/products/" + props.id).then((res) => {
      console.log(res);
    });
  });
  const updateProduct = (e) => {
    e.preventDefault();
    axios
      .put("http://localhost:8000/api/products/" + props.id, {
        title,
        price,
        description,
      })
      .then((res) => {
        setTitle(res.data.title);
        setPrice(res.data.price);
        setDescription(res.data.description);
      });
  };
  return (
    <div>
      <h2>Update a product</h2>
      <form onSubmit={updateProduct}>
        <p>
          <label>Title</label>
          <br />
          <input
            typr="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </p>
        <p>
          <label>Price</label>
          <br />
          <input
            typr="text"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
          />
        </p>
        <p>
          <label>Description</label>
          <br />
          <input
            typr="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </p>
        <input type="submit" />
      </form>
    </div>
  );
};
export default UpdatedById;
