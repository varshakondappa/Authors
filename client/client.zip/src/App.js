import React from "react";
// import ProductForm from "./components/ProductForm";
import "./App.css";
import Products from "./components/Products";
import DetailsById from "./components/DetailsById";
import UpdatedById from "./components/UpdatedById";
import { Router } from "@reach/router";

function App() {
  return (
    <div className="App">
      <Router>
        <Products path="/"></Products>
        <DetailsById path="/products/:id" />
        <UpdatedById path="/products/:id/edit" />
      </Router>
    </div>
  );
}

export default App;
