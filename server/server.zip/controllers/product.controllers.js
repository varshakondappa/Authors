const Product = require("../models/product.models");
// const createProduct = (req, res) => {
//   Product.create(req.body)
//     .then((newProduct) => res.json(newProduct))
//     .catch((err) => console.log(err));
// };

module.exports.createProduct = (request, response) => {
  const { title, price, description } = request.body;
  Product.create({
    title,
    price,
    description,
  })
    .then((person) => response.json(person))
    .catch((err) => response.json(err));
};

module.exports.getAllProducts = (req, res) => {
  Product.find({})
    .then((person) => res.json(person))
    .catch((err) => res.json(err));
};
module.exports.getProductById = (req, res) => {
  Product.findOne({ _id: req.params.id })
    .then((product) => res.json(product))
    .catch((err) => res.json(err));
};
module.exports.updateById = (req, res) => {
  Product.findOneAndUpdate({ _id: req.params.id }, req.body, { new: true })
    .then((product) => res.json(product))
    .catch((err) => res.json(err));
};
module.exports.deleteById = (req, res) => {
  Product.deleteOne({ _id: req.params.id })
    .then((product) => res.json(product))
    .catch((err) => res.json(err));
};
